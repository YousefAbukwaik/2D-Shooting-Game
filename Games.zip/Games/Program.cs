﻿using System;

namespace Games
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            
            Game game = new Game();

           
            


        }

    }
}
